# ETL AI Automation (n8n + Claude)

An n8n workflow that cleans messy student enrollment data with an LLM. Upload a raw CSV through a web form, and Claude standardises every row: names, emails, phone numbers, courses, fee status, cities and dates. The cleaned data comes back as a file you can download.

This is an **ETL (Extract → Transform → Load)** pipeline where the "Transform" step is handled by AI instead of hand-written rules.

---

## Workflow

```
CSV Upload (Form) → Extract from File → Basic LLM Chain (Claude) → Code (JS parse & validate) → Convert to File
                                              ▲
                                    Anthropic Chat Model
```

| # | Node | What it does |
|---|------|--------------|
| 1 | **CSV Upload** (Form Trigger) | Web form where the user uploads the raw student CSV |
| 2 | **Extract from File** | Reads the CSV and turns each row into an n8n item |
| 3 | **Basic LLM Chain** + **Anthropic Chat Model** | Sends each row to Claude with cleaning rules; Claude returns a clean JSON object |
| 4 | **Code in JavaScript** | Strips markdown fences from the LLM output, parses JSON, normalises email and adds an `Email_Valid` flag; bad rows are flagged instead of breaking the run |
| 5 | **Convert to File** | Writes the cleaned rows back to a downloadable file |

---

## Cleaning rules (applied by the LLM)

| Field | Rule |
|-------|------|
| Name | Title Case (`manoj k` → `Manoj K`) |
| Email | Invalid format → `INVALID_EMAIL` |
| Phone | Fewer than 10 digits → `MISSING` |
| Course | Only `Python`, `Machine Learning` or `Data Science` |
| Fee_Paid | `yes`/`YES` → `true`, `no`/`NO` → `false` |
| City | Title Case; empty → `UNKNOWN` |
| Enrolled_Date | Any format → `YYYY-MM-DD` |

### Example

**Input row**
```
stu1001, MANOJ k, manoj@@mail, 98765-43210, python, YES, chennai, 23/05/2025
```

**Output**
```json
{
  "Student_ID": "STU1001",
  "Name": "Manoj K",
  "Email": "invalid_email",
  "Phone": "9876543210",
  "Course": "Python",
  "Fee_Paid": true,
  "City": "Chennai",
  "Enrolled_Date": "2025-05-23",
  "Email_Valid": false
}
```

---

## Lesson learned: LLM output is not always clean JSON

Even with *"Return ONLY raw JSON. No markdown."* in the prompt, the model sometimes wraps its answer in ```` ```json ... ``` ```` fences. In the first version only row 1 parsed; the other 49 failed with `Invalid JSON`.

The fix is a defensive parser in the Code node:

```javascript
s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');   // strip fences
const start = s.indexOf('{');
const end = s.lastIndexOf('}');
s = s.substring(start, end + 1);                                    // keep only the JSON object
return JSON.parse(s);
```

Takeaway: **prompt for structure, but always validate in code.**

---

## Setup

1. **Requirements**
   - n8n (self-hosted or n8n Cloud) with the LangChain nodes (`@n8n/n8n-nodes-langchain`)
   - An Anthropic API key

2. **Import the workflow**
   - In n8n: **Workflows → Import from File** → choose `workflow/etl-ai-automation.json`

3. **Add credentials**
   - Open the **Anthropic Chat Model** node → create a new Anthropic credential with your API key

4. **Run it**
   - Open the **CSV Upload** node and copy the form URL (test or production)
   - Upload `sample-data/students_raw.csv`
   - Download the cleaned file from **Convert to File**

---

## Repository structure

```
n8n-etl-ai-automation/
├── README.md
├── workflow/
│   └── etl-ai-automation.json     # n8n workflow export (credentials removed)
├── sample-data/
│   └── students_raw.csv           # messy test data (fictional)
└── screenshots/                   # add workflow / output screenshots here
```

---

## Ideas for next versions

- Add a **Structured Output Parser** node so n8n enforces the JSON schema
- Split valid and invalid rows into two output files
- Batch rows to cut API calls and cost
- Write cleaned data to Google Sheets or a database instead of a file
- Email a data-quality summary after each run

---

## Tech stack

`n8n` · `Anthropic Claude` · `JavaScript` · `LangChain` · `ETL`

## Author

**Suresh Ramalingam** — IT Infrastructure Architect / Hybrid Cloud & GenAI Implementer
GitHub: [@iamsuresharchitect](https://github.com/iamsuresharchitect)

## License

MIT
